document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const logoutButton = document.getElementById('logout-button');
    const userDisplay = document.getElementById('?????');
    const loginSection = document.getElementById('?????');
    const loggedInSection = document.getElementById('logged-in-section');
    const buyForm = document.getElementById('buy-form');
    const messageBox = document.getElementById('message-box');

    // Q1 Add an event listener for the login button
    document.getElementById('?????').addEventListener('click', async () => {
        const username = document.getElementById('?????').value; // Q2 Get username
        const password = document.getElementById('?????').value; // Q3 Get password

        // Q4 Make a POST request to /login route
        const response = await fetch('?????', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
        });

        // Q5 Handle server response
        if (response.ok) {
            const data = await response.json();
            userDisplay.textContent = data.?????;
            loginSection.style.display = 'none';
            loggedInSection.style.display = 'block';
        } else {
            alert('?????'); // Q6 Alert for login failure
        }
    });

    // Q7 Add an event listener for the logout button
    document.getElementById('?????').addEventListener('click', async () => {
        // Q8 Make a POST request to /logout route
        const response = await fetch('?????', { method: 'POST' });

        // Q9 Handle logout response
        if (response.ok) {
            loginSection.style.display = 'block';
            loggedInSection.style.display = 'none';
            userDisplay.textContent = '';
        } else {
            alert('?????'); // Q10 Alert for logout failure
        }
    });

    // Q11 Check login status on page load
    fetch('?????')
        .then((response) => response.json())
        .then((data) => {
            if (data.?????) {
                userDisplay.textContent = data.?????;
                loginSection.style.display = 'none';
                loggedInSection.style.display = 'block';
            }
        });

    // Q12 Add an event listener for the buy button
    document.getElementById('?????').addEventListener('click', async () => {
        const songId = document.getElementById('?????').value; // Q13 Get song ID

        // Q14 Make a POST request to /buy route
        const response = await fetch('?????', {
            method: '????',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ songId }),
        });

        // Q15 Handle buy response
        if (response.ok) {
            alert('?????'); // Alert for purchase success
        } else if (response.status === 401) {
            alert('?????'); // Alert for unauthorized purchase
        } else {
            alert('?????'); // Alert for general purchase failure
        }
    });
});
