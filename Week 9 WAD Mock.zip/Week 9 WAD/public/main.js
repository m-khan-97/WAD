document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const logoutButton = document.getElementById('logout-button');
    const userDisplay = document.getElementById('user-display');
    const loginSection = document.getElementById('login-section');
    const loggedInSection = document.getElementById('logged-in-section');
    const buyForm = document.getElementById('buy-form');
    const messageBox = document.getElementById('message-box');

    // Login
    document.getElementById('login-button').addEventListener('click', async () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        const response = await fetch('/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
        });

        if (response.ok) {
            const data = await response.json();
            userDisplay.textContent = data.username;
            loginSection.style.display = 'none';
            loggedInSection.style.display = 'block';
        } else {
            alert('Login failed. Please check your credentials.');
        }
    });

    // Logout
    logoutButton.addEventListener('click', async () => {
        const response = await fetch('/logout', { method: 'POST' });
        if (response.ok) {
            loginSection.style.display = 'block';
            loggedInSection.style.display = 'none';
            userDisplay.textContent = '';
        } else {
            alert('Failed to log out.');
        }
    });

    // Check login status on page load
    fetch('/login')
        .then((response) => response.json())
        .then((data) => {
            if (data.username) {
                userDisplay.textContent = data.username;
                loginSection.style.display = 'none';
                loggedInSection.style.display = 'block';
            }
        });

    // Buy Song
    document.getElementById('buy-button').addEventListener('click', async () => {
        const songId = document.getElementById('song-id').value;

        const response = await fetch('/buy', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ songId }),
        });

        if (response.ok) {
            alert('Purchase successful!');
        } else if (response.status === 401) {
            alert('You need to log in to buy a song.');
        } else {
            alert('Failed to purchase the song.');
        }
    });
});
