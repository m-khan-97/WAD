import express from 'express';
import Database from 'better-sqlite3';
import bodyParser from 'body-parser';
import expressSession from 'express-session';
import betterSqlite3Session from 'express-session-better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Q1 Setup database connection
const db = new Database(path.join(__dirname, '?????', '?????'));

// Q2 Setup session database
const sessDb = new Database(path.join(__dirname, '?????', '?????'));
const SqliteStore = betterSqlite3Session(expressSession, sessDb);

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(expressSession({
    store: new SqliteStore(),
    secret: '?????',
    resave: true,
    saveUninitialized: false,
    rolling: true,
    cookie: { maxAge: 600000, httpOnly: false },
}));

// Q3 Middleware to check login status
function authenticate(req, res, next) {
    if (!req.session.?????) {
        return res.status(401).json({ error: "?????" }); // Unauthorized message
    }
    next();
}

// Q4 Login route
app.post('/login', (req, res) => {
    const { ?????, ????? } = req.body; // Q5 Get username and password
    const stmt = db.prepare('?????'); // Q6 Query database
    const user = stmt.get(?????, ?????); // Q7 Execute query

    // Q8 Handle login success or failure
    if (?????) {
        req.session.username = ?????;
        res.json({ success: true, username: ????? });
    } else {
        res.status(401).json({ error: "?????" }); // Login failure message
    }
});

// Q9 Logout route
app.post('/logout', (req, res) => {
    req.session = null; // Destroy session
    res.json({ success: true });
});

// Q10 Check current login status
app.get('/login', (req, res) => {
    res.json({ username: req.session.????? || null }); // Return current username if logged in
});

// Q11 Buy route
app.post('/buy', authenticate, (req, res) => {
    const { ????? } = req.body; // Q12 Get song ID
    const stmt = db.prepare('?????'); // Q13 Update purchases
    stmt.run(?????); // Q14 Execute query
    res.json({ success: true, message: "?????" }); // Purchase success message
});

// Q15 Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
