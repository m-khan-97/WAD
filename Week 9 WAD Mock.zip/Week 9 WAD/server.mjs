import express from 'express';
import Database from 'better-sqlite3';
import bodyParser from 'body-parser';
import expressSession from 'express-session';
import betterSqlite3Session from 'express-session-better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Database setup
const db = new Database(path.join(__dirname, 'database', 'wadsongs.db'));

// Session setup
const sessDb = new Database(path.join(__dirname, 'database', 'session.db'));
const SqliteStore = betterSqlite3Session(expressSession, sessDb);

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(expressSession({
    store: new SqliteStore(),
    secret: 'YourSecretKey',
    resave: true,
    saveUninitialized: false,
    rolling: true,
    cookie: { maxAge: 600000, httpOnly: false },
}));

// Middleware to check login status
function authenticate(req, res, next) {
    if (!req.session.username) {
        return res.status(401).json({ error: "Unauthorized: Please log in." });
    }
    next();
}

// Routes
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const stmt = db.prepare('SELECT * FROM ht_users WHERE username = ? AND password = ?');
    const user = stmt.get(username, password);

    if (user) {
        req.session.username = username;
        res.json({ success: true, username });
    } else {
        res.status(401).json({ error: "Invalid username or password." });
    }
});

app.post('/logout', (req, res) => {
    req.session = null;
    res.json({ success: true });
});

app.get('/login', (req, res) => {
    res.json({ username: req.session.username || null });
});

app.post('/buy', authenticate, (req, res) => {
    const { songId } = req.body;
    const stmt = db.prepare('UPDATE songs SET purchases = purchases + 1 WHERE id = ?');
    stmt.run(songId);
    res.json({ success: true, message: "Purchase successful!" });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
