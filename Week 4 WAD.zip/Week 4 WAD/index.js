import express from 'express';
import path from 'path';
import sqlite3 from 'sqlite3';

const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.json());

// Connect to the database
const db = new sqlite3.Database('./wadsongs.db', (err) => {
    if (err) {
        console.error('Error connecting to database:', err);
    } else {
        console.log('Connected to the wadsongs.db database.');
    }
});

// Updated artist search route to match database structure
app.get('/artist', (req, res) => {
    const artistName = req.query.name;
    
    // Query database for artist and song details
    db.get('SELECT artist, title AS song, year FROM songs WHERE LOWER(artist) = LOWER(?)', [artistName], (err, row) => {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'An error occurred while fetching the artist data' });
        } else if (row) {
            res.json(row);  // Return the song details if found
        } else {
            res.status(404).json({ error: 'Artist not found' });
        }
    });
});

// Updated add song route to match database structure
app.post('/add-song', (req, res) => {
    const { artist, song, year } = req.body;

    if (!artist || !song || !year) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    // Insert new song into the database
    db.run('INSERT INTO songs (artist, title, year) VALUES (?, ?, ?)', [artist, song, year], function(err) {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'An error occurred while adding the song' });
        } else {
            res.status(201).json({ message: 'Song added successfully', song: { artist, song, year } });
        }
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
