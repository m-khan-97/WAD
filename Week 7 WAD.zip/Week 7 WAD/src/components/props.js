import React from "react";
function Greetings({ name }) {
    return <p>Hello {name}!</p>;
}

export default Greetings;
