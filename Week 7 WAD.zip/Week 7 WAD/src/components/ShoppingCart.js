import React from 'react';

let itemId = 1;

function ShoppingCart() {
    const [cart, setCart] = React.useState([]);

    function addItem() {
        const items = [...cart];
        items.push({
            id: itemId++,
            name: document.getElementById('item').value
        });
        setCart(items);
    }

    return (
        <div>
            <h1>Shopping Cart</h1>
            <input id='item' />
            <button onClick={addItem}>Add Item</button>
            <ul>
                {cart.map(item => <li key={item.id}>{item.name}</li>)}
            </ul>
        </div>
    );
}

export default ShoppingCart;
