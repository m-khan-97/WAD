import React from 'react';
import ReactDOM from 'react-dom/client';
import Greeting from './components/greeting.js';
import Greetings from './components/props.js';
import ShoppingCart from './components/ShoppingCart.js';

const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(<Greeting />);
// root.render(<Greetings name="John" />);
root.render(<ShoppingCart />);


