// db.mjs - Initialize and export the database connection object
import Database from 'better-sqlite3';
import 'dotenv/config'; // Load environment variables from .env file

// Use the DB_NAME from the .env file
const db = new Database(process.env.DB_NAME); 
export default db;
