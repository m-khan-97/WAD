import express from 'express';
import sqlite3 from 'better-sqlite3';
import bodyParser from 'body-parser';
import expressSession from 'express-session';
import betterSqlite3Session from 'express-session-better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

import 'dotenv/config'; // Import dotenv
import userMiddleware from './routes/middleware.mjs';
import userRouter from './routes/users.mjs';
import songRouter from './routes/songs.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Database setup
const db = new sqlite3(process.env.DB_NAME);
const sessDb = new sqlite3(process.env.SESSION_DB);

// Session setup
const SqliteStore = betterSqlite3Session(expressSession, sessDb);
app.use(expressSession({
    store: new SqliteStore(),
    secret: 'YourSecretKey',
    resave: true,
    saveUninitialized: false,
    rolling: true,
    cookie: { maxAge: 600000, httpOnly: false },
}));


app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Use middleware
app.use('/songs', userMiddleware); // Apply only to /songs

// Add routers
app.use('/users', userRouter);
app.use('/songs', songRouter);

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
