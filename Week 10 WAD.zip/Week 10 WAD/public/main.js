document.addEventListener('DOMContentLoaded', () => {
    const loginSection = document.getElementById('login-section');
    const loggedInSection = document.getElementById('logged-in-section');
    const userDisplay = document.getElementById('user-display');
    const songsList = document.getElementById('songs-list');

    // Login
    document.getElementById('login-button').addEventListener('click', async () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        const response = await fetch('/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
        });

        if (response.ok) {
            const data = await response.json();
            userDisplay.textContent = data.username;
            loginSection.style.display = 'none';
            loggedInSection.style.display = 'block';
        } else {
            alert('Invalid login credentials.');
        }
    });

    // Logout
    document.getElementById('logout-button').addEventListener('click', async () => {
        const response = await fetch('/users/logout', { method: 'POST' });
        if (response.ok) {
            userDisplay.textContent = '';
            loginSection.style.display = 'block';
            loggedInSection.style.display = 'none';
        }
    });

    // Search Songs
    document.getElementById('search-button').addEventListener('click', async () => {
        const artistName = document.getElementById('artist-name').value;

        const response = await fetch(`/songs/artist/${artistName}`);
        if (response.ok) {
            const songs = await response.json();
            songsList.innerHTML = songs.map(song => `<p>${song.title} by ${song.artist}</p>`).join('');
        } else {
            songsList.textContent = 'No songs found.';
        }
    });
});
