// routes/users.mjs
import express from 'express';
import db from '../db.mjs';

const usersRouter = express.Router();

// POST /users/login
usersRouter.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Query database for user credentials
    const stmt = db.prepare('SELECT * FROM ht_users WHERE username = ? AND password = ?');
    const user = stmt.get(username, password);
    
    if (user) {
        req.session.username = username; // Store username in session
        res.json({ success: true, username }); // Respond with success
    } else {
        res.status(401).json({ error: "Invalid username or password." });
    }
});


// GET /users/login
usersRouter.get('/login', (req, res) => {
    res.json({ username: req.session.username || null });
});

// POST /users/logout
usersRouter.post('/logout', (req, res) => {
    req.session = null;
    res.json({ success: true });
});

export default usersRouter;
