// middleware.mjs
export default function userMiddleware(req, res, next) {
    if (req.session && req.session.username) {
        return next(); // User is authenticated
    }
    
    // Check if the route is /users/login or /users/logout
    const openRoutes = ['/users/login', '/users/logout'];
    if (openRoutes.includes(req.path)) {
        return next(); // Allow open routes without authentication
    }
    
    return res.status(401).json({ error: "Unauthorized: Please log in." });
}
