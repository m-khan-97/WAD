// routes/songs.mjs
import express from 'express';
import db from '../db.mjs';

const songsRouter = express.Router();

// GET /songs/artist/:artistName
songsRouter.get('/artist/:artistName', (req, res) => {
    const artistName = req.params.artistName;
    const stmt = db.prepare('SELECT * FROM songs WHERE artist = ?');
    const songs = stmt.all(artistName);

    res.json(songs);
});

// POST /songs/buy
songsRouter.post('/buy', (req, res) => {
    const { songId } = req.body;
    const stmt = db.prepare('UPDATE songs SET purchases = purchases + 1 WHERE id = ?');
    stmt.run(songId);

    res.json({ success: true, message: "Song purchased successfully!" });
});

export default songsRouter;
