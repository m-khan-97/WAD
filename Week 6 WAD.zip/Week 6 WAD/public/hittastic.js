
// Search for artist songs
document.getElementById('searchButton').addEventListener('click', function () {
    const artistName = document.getElementById('artistSearchInput').value;
    fetch(`/artist?name=${encodeURIComponent(artistName)}`)
        .then((response) => response.json())
        .then((songs) => {
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = ''; // Clear previous results

            songs.forEach((song) => {
                const songDiv = document.createElement('div');
                songDiv.classList.add('song-result');
                songDiv.innerHTML = `
                    <p>Artist: ${song.artist || 'Unknown'}</p>
                    <p>Song: ${song.song}</p>
                    <p>Year: ${song.year} ${song.year < 2000 ? '(CLASSIC HIT!)' : ''}</p>
                    <p>Purchases: ${song.purchases}</p>
                    <label for="quantity-${song.id}">Quantity:</label>
                    <input type="number" id="quantity-${song.id}" value="1" min="1" class="form-control mb-2" />
                `;

                const buyButton = document.createElement('button');
                buyButton.textContent = 'Buy Song';
                songDiv.appendChild(buyButton);

                // Add event listener to the "Buy Song" button for each song
                buyButton.addEventListener('click', function () {
                    const quantityInput = document.getElementById(`quantity-${song.id}`);
                    const quantity = parseInt(quantityInput.value);

                    if (isNaN(quantity) || quantity < 1) {
                        alert('Please enter a valid quantity.');
                        return;
                    }

                    fetch('/buy', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ songId: song.id, quantity }),
                    })
                        .then((response) => response.json())
                        .then((data) => {
                            alert(data.message); // Show success message
                            song.purchases += quantity; // Update purchases count locally
                            songDiv.querySelector('p:nth-child(4)').textContent = `Purchases: ${song.purchases}`;
                        })
                        .catch((error) => {
                            console.error('An error occurred:', error);
                            alert('An error occurred while purchasing the song.');
                        });
                });

                resultsDiv.appendChild(songDiv);
            });
        })
        .catch((error) => {
            console.error(error);
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = `<p>An error occurred: ${error.message}</p>`;
        });
});

// Add song functionality
document.getElementById('addSongForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    const artist = document.getElementById('newArtist').value;
    const song = document.getElementById('newSong').value;
    const year = document.getElementById('newYear').value;

    fetch('/add-song', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ artist, song, year }),
    })
        .then((response) => {
            if (!response.ok) {
                throw new Error(`An error occurred: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            alert(data.message);
            document.getElementById('addSongForm').reset();
        })
        .catch((error) => {
            alert(error.message); // Show error message
        });
});

import 'leaflet';

// Initialize Leaflet map
const map = L.map('map').setView([51.586, -0.019], 13); // Default: Walthamstow, London
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'Map data © OpenStreetMap contributors',
}).addTo(map);

// Clear markers layer to avoid duplication
let markersLayer = L.layerGroup().addTo(map);

// Fetch and display artist's hometown
document.getElementById('hometownButton').addEventListener('click', () => {
    const artistName = document.getElementById('artistSearchInput').value;

    fetch(`/hometown/${encodeURIComponent(artistName)}`)
        .then((response) => response.json())
        .then(({ hometown, latitude, longitude }) => {
            // Clear previous markers
            markersLayer.clearLayers();

            // Add new marker and center map
            const marker = L.marker([latitude, longitude]).addTo(markersLayer);
            marker.bindPopup(`Hometown: ${hometown}`).openPopup();

            map.setView([latitude, longitude], 13);
        })
        .catch((error) => {
            console.error(error);
            alert('Hometown not found for this artist.');
        });
});

// Handle map click event to add a new hometown
map.on('click', (e) => {
    const latitude = e.latlng.lat;
    const longitude = e.latlng.lng;

    // Prompt user for artist name and hometown
    const artist = prompt('Please enter an artist name');
    if (!artist) {
        alert('Artist name is required!');
        return;
    }

    const hometown = prompt('Please enter the hometown name');
    if (!hometown) {
        alert('Hometown name is required!');
        return;
    }

    // Send a POST request to add the new hometown
    fetch('/add-hometown', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ artist, hometown, latitude, longitude }),
    })
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            alert(data.message); // Show success message

            // Add a marker to the map
            const marker = L.marker([latitude, longitude]).addTo(map);
            marker.bindPopup(`Hometown: ${hometown}<br>Artist: ${artist}`).openPopup();
        })
        .catch((error) => {
            console.error('An error occurred:', error);
            alert('An error occurred while adding the hometown.');
        });
});
