import 'leaflet';

const map = L.map('map').setView([51.57734, -0.0347], 20); // Walthamstow, London

// Add the OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'Map data © OpenStreetMap contributors',
}).addTo(map);

const hometownMarker = L.marker([51.57734, -0.0347]).addTo(map);
hometownMarker.bindPopup('Welcome to Walthamstow, London!');

// Add a click event listener to the map
map.on('click', (event) => {
    // Get the latitude and longitude of the clicked position
    const { lat, lng } = event.latlng;

    // Prompt the user for marker text
    const text = prompt('Please enter some text for the marker:');

    if (text) {
        // Add a marker at the clicked position
        const newMarker = L.marker([lat, lng]).addTo(map);

        // Bind the entered text as a popup to the marker
        newMarker.bindPopup(text).openPopup();
    }
});



























