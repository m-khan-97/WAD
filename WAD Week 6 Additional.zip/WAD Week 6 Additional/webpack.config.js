import path from 'path';

export default {
    mode: 'development',
    entry: './public/index.js',
    output: {
        path: path.resolve(process.cwd(), 'public/dist'),
        filename: 'bundle.js',
    },
    optimization: {
        minimize: false,
    },
    module: {
        rules: [
            {
                test: /\.css$/i,
                use: ['style-loader', 'css-loader'],
            },
        ],
    },
};
