import React, { useState } from "react";
import InputComponent from "./InputComponent";
import ResultsComponent from "./ResultsComponent";
// import LeafletMap from "./LeafletMap2";

function ArtistSearchApp() {
  const [artistName, setArtistName] = useState("");
  const [searchResults, setSearchResults] = useState([]);

  function handleSearch(name) {
    setArtistName(name);
  
    // Perform AJAX call to fetch artist data
    fetch(`/artist?name=${name}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => setSearchResults(data))
  //       .then((data) =>
  //   setSearchResults(
  //     data.map((song, index) => ({
  //       ...song,
  //       lat: 51.505 + index * 0.01, // Mock lat
  //       lon: -0.09 + index * 0.01, // Mock lon
  //     }))
  //   )
  // )
      .catch((error) => {
        console.error("Error fetching artist:", error);
        setSearchResults([]); // Clear results on error
      });
  }

  return (
    <div>
      <InputComponent onSearch={handleSearch} />
      <ResultsComponent results={searchResults} />
      {/* <LeafletMap results={searchResults} /> */}
    </div>
  );
}

export default ArtistSearchApp;
