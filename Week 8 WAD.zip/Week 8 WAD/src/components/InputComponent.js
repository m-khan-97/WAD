import React, { useState } from "react";

function InputComponent({ onSearch }) {
  const [inputValue, setInputValue] = useState("");

  function handleSubmit() {
    onSearch(inputValue);
  }

  return (
    <div>
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder="Enter artist name"
      />
      <button onClick={handleSubmit}>Search</button>
    </div>
  );
}

export default InputComponent;
