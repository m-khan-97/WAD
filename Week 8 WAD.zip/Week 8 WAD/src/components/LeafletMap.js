import React, { useRef, useState, useEffect } from 'react';
import 'leaflet';
import 'leaflet/dist/leaflet.css';

function LeafletMap() {
    const mapRef = useRef(null);
    const [lat, setLat] = useState(51.05);
    const [lon, setLon] = useState(-0.72);
    const [markers, setMarkers] = useState([]);

    const searchPlace = async (placeName) => {
        const response = await fetch(`https://hikar.org/webapp/nomproxy?q=${placeName}`);
        const data = await response.json();
        if (data.length > 0) {
            const firstResult = data[0];
            setLat(firstResult.lat);
            setLon(firstResult.lon);
            setMarkers(data);
        }
    };

    useEffect(() => {
        if (!mapRef.current) {
            mapRef.current = L.map('map').setView([lat, lon], 13);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
            }).addTo(mapRef.current);
        } else {
            mapRef.current.setView([lat, lon], 13);
        }

        // Add markers to the map
        markers.forEach((marker) => {
            L.marker([marker.lat, marker.lon]).addTo(mapRef.current).bindPopup(marker.display_name);
        });
    }, [lat, lon, markers]);

    return (
        <div>
            <input
                type="text"
                id="place-name"
                placeholder="Enter place name"
            />
            <button onClick={() => searchPlace(document.getElementById('place-name').value)}>
                Search
            </button>
            <div id="map" style={{ height: '500px', width: '100%' }}></div>
        </div>
    );
}

export default LeafletMap;
