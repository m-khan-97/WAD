import React from "react";
function ResultsComponent({ results }) {
    return (
      <div>
        <h3>Search Results:</h3>
        {results.length > 0 ? (
          <ul>
            {results.map((result, index) => (
              <li key={index}>{result.title}</li>
            ))}
          </ul>
        ) : (
          <p>No results found.</p>
        )}
      </div>
    );
  }
  
  export default ResultsComponent;
  