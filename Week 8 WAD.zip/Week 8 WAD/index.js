import express from 'express';
import path from 'path';

const app = express();
const port = 3000;

// Serve static files
app.use(express.static(path.join(process.cwd(), 'public')));

// Mock data for artists
const artists = [
    { name: 'Artist1', songs: [{ title: 'Song1' }, { title: 'Song2' }], genre: 'Pop' },
    { name: 'Artist2', songs: [{ title: 'SongA' }, { title: 'SongB' }], genre: 'Rock' },
];

// Define the /artist route
app.get('/artist', (req, res) => {
    const artistName = req.query.name;
    const artist = artists.find((a) => a.name.toLowerCase() === artistName.toLowerCase());

    if (artist) {
        res.json(artist.songs); // Return only the songs array for the artist
    } else {
        res.status(404).json({ error: 'Artist not found' });
    }
});


// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
