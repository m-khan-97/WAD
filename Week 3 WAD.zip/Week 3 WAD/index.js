import express from 'express';
import path from 'path';

const app = express();
const port = 3000;

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Sample artist data
const artists = [
    { name: 'Artist A', song: 'Song A', year: 1995 },
    { name: 'Artist B', song: 'Song B', year: 2003 },
    { name: 'Artist C', song: 'Song C', year: 1987 }
];

// Add your /artist route
app.get('/artist', (req, res) => {
    const artistName = req.query.name;
    const artist = artists.find(a => a.name.toLowerCase() === artistName.toLowerCase());

    if (artist) {
        res.json(artist); // This should return the artist object
    } else {
        res.status(404).json({ error: 'Artist not found' });
    }
});
// Array to hold songs (you may want to use a database in a real application)
const songs = [];

// Add new song route
app.post('/add-song', express.json(), (req, res) => {
    const { artist, song, year } = req.body;

    // Basic validation
    if (!artist || !song || !year) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    // Add the new song to the songs array
    songs.push({ name: artist, song, year });
    res.status(201).json({ message: 'Song added successfully', song: { artist, song, year } });
});


app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
