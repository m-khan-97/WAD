document.getElementById('searchButton').addEventListener('click', function() {
    const artistName = document.getElementById('artistInput').value;
    fetch(`/artist?name=${encodeURIComponent(artistName)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json(); // Parse the JSON response
        })
        .then(data => {
            // Check if data is defined and contains the expected properties
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = `
                <p>Artist: ${data.name || 'Unknown'}</p>
                <p>Song: ${data.song}</p>
                <p>Year: ${data.year} ${data.year < 2000 ? '(CLASSIC HIT!)' : ''}</p>
            `;
        })
        .catch(error => {
            console.error('An error occurred:', error);
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = `<p>An error occurred: ${error.message}</p>`;
        });
});


document.getElementById('addSongForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    const artist = document.getElementById('newArtist').value;
    const song = document.getElementById('newSong').value;
    const year = document.getElementById('newYear').value;

    // Send an AJAX POST request to add the new song
    fetch('/add-song', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ artist, song, year })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`An error occurred: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        alert(data.message); // Show success message
        // Optionally, you can clear the form fields
        document.getElementById('addSongForm').reset();
    })
    .catch(error => {
        alert(error.message); // Show error message
    });
});
