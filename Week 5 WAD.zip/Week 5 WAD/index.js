import express from 'express';
import path from 'path';
import sqlite3 from 'sqlite3';

const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.json());

// Connect to the database
const db = new sqlite3.Database('./wadsongs.db', (err) => {
    if (err) {
        console.error('Error connecting to database:', err);
    } else {
        console.log('Connected to the wadsongs.db database.');
    }
});

// Artist search route
app.get('/artist', (req, res) => {
    const artistName = req.query.name;
    
    // Query database for artist and song details
    db.all('SELECT id, artist, title AS song, year, purchases FROM songs WHERE LOWER(artist) = LOWER(?)', [artistName], (err, rows) => {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'An error occurred while fetching the artist data' });
        } else if (rows.length > 0) {
            res.json(rows);  // Return the list of songs
        } else {
            res.status(404).json({ error: 'Artist not found' });
        }
    });
});

// Add song route
app.post('/add-song', (req, res) => {
    const { artist, song, year } = req.body;

    if (!artist || !song || !year) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    // Insert new song into the database
    db.run('INSERT INTO songs (artist, title, year, purchases) VALUES (?, ?, ?, 0)', [artist, song, year], function(err) {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'An error occurred while adding the song' });
        } else {
            res.status(201).json({ message: 'Song added successfully', song: { artist, song, year } });
        }
    });
});

// Increment purchases for a specific song
app.post('/buy', (req, res) => {
    const { songId } = req.body;

    db.run('UPDATE songs SET purchases = purchases + 1 WHERE id = ?', [songId], function(err) {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'An error occurred while processing the purchase' });
        }
        res.status(200).json({ message: 'Song purchased successfully' });
    });
});

// app.post('/buy', (req, res) => {
//     const { songId, quantity } = req.body;

//     // Validate input
//     if (!songId || !quantity || quantity < 1) {
//         return res.status(400).json({ error: 'Invalid song ID or quantity' });
//     }

//     // Update purchases by subtracting the specified quantity
//     db.run(
//         'UPDATE songs SET purchases = purchases + ? WHERE id = ?',
//         [quantity, songId],
//         function (err) {
//             if (err) {
//                 console.error(err);
//                 return res.status(500).json({ error: 'An error occurred while processing the purchase' });
//             }

//             if (this.changes === 0) {
//                 // No rows updated, meaning invalid song ID
//                 return res.status(404).json({ error: 'Song not found' });
//             }

//             res.status(200).json({ message: `Successfully purchased ${quantity} copy/copies of the song` });
//         }
//     );
// });

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
