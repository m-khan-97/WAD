document.getElementById('searchButton').addEventListener('click', function() {
    const artistName = document.getElementById('artistInput').value;
    fetch(`/artist?name=${encodeURIComponent(artistName)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = '';  // Clear previous results

            data.forEach(song => {
                const songDiv = document.createElement('div');
                songDiv.classList.add('song-result');
                songDiv.innerHTML = `
                    <p>Artist: ${song.artist || 'Unknown'}</p>
                    <p>Song: ${song.song}</p>
                    <p>Year: ${song.year} ${song.year < 2000 ? '(CLASSIC HIT!)' : ''}</p>
                    <p>Purchases: ${song.purchases || 0}</p>
                `;

                const buyButton = document.createElement('button');
                buyButton.textContent = 'Buy Song';
                songDiv.appendChild(buyButton);

                // Add event listener to the "Buy Song" button for each song
                buyButton.addEventListener('click', function() {
                    fetch('/buy', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ songId: song.id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message);  // Show success message
                        // Update purchases count after buying
                        song.purchases += 1;
                        songDiv.querySelector('p:nth-child(4)').textContent = `Purchases: ${song.purchases}`;
                    })
                    .catch(error => {
                        console.error('An error occurred:', error);
                        alert('An error occurred while purchasing the song.');
                    });
                });

                resultsDiv.appendChild(songDiv);
            });
        })
        .catch(error => {
            console.error('An error occurred:', error);
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = `<p>An error occurred: ${error.message}</p>`;
        });
});

// document.getElementById('searchButton').addEventListener('click', function () {
//     const artistName = document.getElementById('artistInput').value;
//     fetch(`/artist?name=${encodeURIComponent(artistName)}`)
//         .then((response) => {
//             if (!response.ok) {
//                 throw new Error(`HTTP error! status: ${response.status}`);
//             }
//             return response.json();
//         })
//         .then((data) => {
//             const resultsDiv = document.getElementById('results');
//             resultsDiv.innerHTML = ''; // Clear previous results

//             data.forEach((song) => {
//                 const songDiv = document.createElement('div');
//                 songDiv.classList.add('song-result');
//                 songDiv.innerHTML = `
//                     <p>Artist: ${song.artist || 'Unknown'}</p>
//                     <p>Song: ${song.song}</p>
//                     <p>Year: ${song.year} ${song.year < 2000 ? '(CLASSIC HIT!)' : ''}</p>
//                     <p>Purchases: ${song.purchases}</p>
//                     <label for="quantity-${song.id}">Quantity:</label>
//                     <input type="number" id="quantity-${song.id}" value="1" min="1" class="form-control mb-2" />
//                 `;

//                 const buyButton = document.createElement('button');
//                 buyButton.textContent = 'Buy Song';
//                 songDiv.appendChild(buyButton);

//                 // Add event listener to the "Buy Song" button for each song
//                 buyButton.addEventListener('click', function () {
//                     const quantityInput = document.getElementById(`quantity-${song.id}`);
//                     const quantity = parseInt(quantityInput.value);

//                     if (isNaN(quantity) || quantity < 1) {
//                         alert('Please enter a valid quantity.');
//                         return;
//                     }

//                     fetch('/buy', {
//                         method: 'POST',
//                         headers: {
//                             'Content-Type': 'application/json',
//                         },
//                         body: JSON.stringify({ songId: song.id, quantity }),
//                     })
//                         .then((response) => response.json())
//                         .then((data) => {
//                             alert(data.message); // Show success message
//                             song.purchases += quantity; // Update purchases count locally
//                             songDiv.querySelector('p:nth-child(4)').textContent = `Purchases: ${song.purchases}`;
//                         })
//                         .catch((error) => {
//                             console.error('An error occurred:', error);
//                             alert('An error occurred while purchasing the song.');
//                         });
//                 });

//                 resultsDiv.appendChild(songDiv);
//             });
//         })
//         .catch((error) => {
//             console.error('An error occurred:', error);
//             const resultsDiv = document.getElementById('results');
//             resultsDiv.innerHTML = `<p>An error occurred: ${error.message}</p>`;
//         });
// });


document.getElementById('addSongForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    const artist = document.getElementById('newArtist').value;
    const song = document.getElementById('newSong').value;
    const year = document.getElementById('newYear').value;

    fetch('/add-song', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ artist, song, year })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`An error occurred: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        alert(data.message); 
        document.getElementById('addSongForm').reset();
    })
    .catch(error => {
        alert(error.message); // Show error message
    });
});
