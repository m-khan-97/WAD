// index.js:
// "Buy" route
app.post('/buy', (req, res) => {
    const { songId, userId } = req.body;

    // Simulate buying the song (you can modify this logic to reflect actual transaction logic)
    db.run('UPDATE songs SET purchases = 1 WHERE id = ?', [songId], function(err) {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'An error occurred while processing the purchase' });
        }
        // Respond with success message after updating the song record
        res.status(200).json({ message: `Song purchased successfully` });
    });
});

// hittastic.js

            // Create a "Buy Song" button below the song details
            const buyButton = document.createElement('button');
            buyButton.textContent = 'Buy Song';
            resultsDiv.appendChild(buyButton);

            // Add event listener to the "Buy Song" button
            buyButton.addEventListener('click', function() {
                const songId = data.id;
                const userId = 1;  // Replace with actual user ID from session or context

                // Send AJAX POST request to buy the song
                fetch('/buy', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ songId, userId })
                })
                .then(response => response.json())
                .then(data => {
                    // Show success message below the song
                    resultsDiv.innerHTML += `<p>Song purchased successfully!</p>`;
                })
                .catch(error => {
                    console.error('An error occurred:', error);
                    alert('An error occurred while purchasing the song.');
                });
            });