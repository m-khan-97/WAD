import React from "react";
import { useState } from "react";

function InteractiveGreeting() {
    const [name, setName] = useState("No Name");
    function updateStateName(e) {
        setName(e.target.value);
    }


return(
    <div>
        <h2>Enter your Name</h2>
        <input type="text" value={name} onChange={updateStateName} />
        <div>Hello {name}</div>
    </div>
)
}
export default InteractiveGreeting