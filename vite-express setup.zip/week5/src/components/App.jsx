import React from "react";
import InputComponent from "./inputcomponent";
import Greeting from "./Greeting";
import ListComponent from "./ListComponent";
import ShoppingCart from "./shoppingcart";
import Timer from "./Timer";
import LeafletMap from "./LeafletMap";

function App ({title, defaultName}) {
    const [name, setName] = React.useState(defaultName);

    function updateStateName(name) {
        setName(name);
    }

    return (
        <div>
            <InputComponent title={title} onNameEntered={updateStateName}></InputComponent>
            <Greeting name={name}></Greeting>
            <ListComponent></ListComponent>
            <ShoppingCart store="Amazon"></ShoppingCart>
            <Timer></Timer>
            <LeafletMap></LeafletMap>
 
        </div>
    );
}

export default App