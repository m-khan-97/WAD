import React from "react";

function InputComponent({title, onNameEntered}) {
    function updateName() {
        const n = document.getElementById('name').value;
        onNameEntered(n)
    }

    return(
        <div>
            <h1>{title}</h1>
            <input type="text" id="name" onChange={updateName}></input>
        </div>

    );
}
export default InputComponent;