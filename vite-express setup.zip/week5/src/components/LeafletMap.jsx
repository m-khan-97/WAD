import { useRef, useState, useEffect } from "react";
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export default function LeafletMap() {
    const map = useRef(null);
    const [lat, setLat] = useState(51.05);
    const [lon, setLon] = useState(-0.72);

    useEffect(() => {
        if (map.current === null) {
            map.current = L.map("map1");
            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: "&copy OpenStreetMap contributors"
            }).addTo(map.current);

            map.current.setView([lat, lon], 14);

            map.current.on("moveend", () => {
                const centre = map.current.getCenter();
                setLat(centre.lat);
                setLon(centre.lng)
            });
        }
    }, []);

    function setPos() {
        const lt = parseFloat(document.getElementById('lat').value);
        const lng = parseFloat(document.getElementById('lon').value);
        setLat(lt);
        setLon(lng);
        map.current.setView([lt, lng], 14);

    }

    return (
        <div>
            Lat: <input id="lat" defaultValue={lat}></input>
            Lon: <input id="lon" defaultValue={lon}></input>
            <input type="button" value='Go' onClick={setPos}></input>
            <p>Msp centered at : {lat} {lon}</p>
            <div id="map1" style={{width: "800px", height: "600px" }}></div>

        </div>
    );
}