import React from "react";
import { useState } from "react";

let itemId = 1;

function ShoppingCart({store}) {
    const [cart, setCart] = useState([]);

    const cartHtml = cart.map(item => (
        <li key={item.id}>{item.name}</li>
    ));

    function addItems() {
        const items = structuredClone(cart);
        const newItem = {
            id: itemId++,
            name: document.getElementById('item').value
        };
        items.push(newItem);
        setCart(items);
    }

    return (
        <div>
            <h1>{store} Shopping Cart</h1>
            <input id="item"></input>   
            <button onClick={addItems}>Add to Cart</button>
            <ul>{cartHtml}</ul>
        </div>

    );
}
export default ShoppingCart;