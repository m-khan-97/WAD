import React from "react";

function ListComponent() {
    const modules = ["WAD", "OODD", "CWA", "Intro to Databases"];
    const modulesList = modules.map(module => 
        <li key={modules}>{module}</li>
    );

    return <ul>{modulesList}</ul>
}

export default ListComponent