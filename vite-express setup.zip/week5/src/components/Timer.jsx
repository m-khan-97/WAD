import { useState, useRef } from "react";

export default function Timer () {
    const timerHandle = useRef(null);
    const [startTime, setStartTime] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);

    function startTimer () {
        if (timerHandle.current == null) {
            const initialTime = Math.round(Date.now());
            setStartTime(initialTime);
            setCurrentTime(initialTime);

            timerHandle.current = setInterval(() => {
                const timeNow = Math.round(Date.now());
                setCurrentTime(timeNow);
            }, 1000);
        }
    }

    function stopTimer() {
        if (timerHandle.current != null) {
            clearInterval(timerHandle.current);
            timerHandle.current = null;
        }
    }

    return (
        <div>
            Time: {Math.round((currentTime - startTime) / 1000)} seconds <br />
            <input type="button" value='Start' onClick={startTimer}></input>
            <input type="button" value='Stop' onClick={stopTimer}></input>
        </div>
    );
}