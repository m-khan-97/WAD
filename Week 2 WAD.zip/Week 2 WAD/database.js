import Database from 'better-sqlite3';
const db = new Database('mydatabase.db');
db.prepare(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT
    )
`).run();

const insert = db.prepare('INSERT INTO users (name, email) VALUES (?, ?)');
insert.run('Muhammad Ibrahim', 'mibrahim@qa.com');
const users = db.prepare('SELECT * FROM users').all();

console.log(users);
