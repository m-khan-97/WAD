import express from 'express';
import Database from 'better-sqlite3';

const app = express();
const port = 3000;

app.use(express.json());
const db = new Database('mydatabase.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    firstname TEXT NOT NULL,
    lastname TEXT NOT NULL
  );

  INSERT INTO students (firstname, lastname) VALUES ('Alexandru', 'Modiga');
  INSERT INTO students (firstname, lastname) VALUES ('Beata', 'Hajduk');
  INSERT INTO students (firstname, lastname) VALUES ('Jerzy Pawel', 'Lepecki');
  INSERT INTO students (firstname, lastname) VALUES ('Kelly Adriane', 'Adamuccio');
  INSERT INTO students (firstname, lastname) VALUES ('Konrad', 'Banaszewski');
  INSERT INTO students (firstname, lastname) VALUES ('Mariano', 'Minopoli');
  INSERT INTO students (firstname, lastname) VALUES ('MIHAELA', 'BETEA');
  INSERT INTO students (firstname, lastname) VALUES ('Valentin', 'Olteanu');
  INSERT INTO students (firstname, lastname) VALUES ('Vilin', 'Hristov');
`);

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
