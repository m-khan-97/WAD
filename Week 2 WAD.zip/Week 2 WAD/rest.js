import express from 'express';
import Database from 'better-sqlite3';
import cors from 'cors';

const app = express();
const port = 3000;

app.use(cors());//Cross-Origin Resource Sharing
app.use(express.json());
const db = new Database('mydatabase.db');

app.get('/' , (req , res) =>{
  res.send('Hello and Welcome to DB')
} )
app.get('/students', (req, res) => {
  try {
    const stmt = db.prepare("SELECT * FROM students");
    const results = stmt.all();
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
app.get('/students/:lastname', (req , res) => {
  try{
      const stmt=db.prepare("SELECT * FROM students WHERE lastname = ?");
      const results = stmt.all(req.params.lastname);
      res.json(results);}
  catch (error) {
          res.status(500).json({ error: error.message });
        }    
  });
  app.post('/students', (req, res) => {
    const { firstname, lastname } = req.body;
    try {
        const stmt = db.prepare("INSERT INTO students (firstname, lastname) VALUES (?, ?)");
        const result = stmt.run(firstname, lastname);
        res.json({ success: true, id: result.lastInsertRowid });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.delete('/students/:id', (req, res) => {
  const studentId = req.params.id;

  try {
    const stmt = db.prepare("DELETE FROM students WHERE id = ?");
    const result = stmt.run(studentId);

    if (result.changes > 0) {
      res.json({ success: true, message: `Student with ID ${studentId} deleted` });
    } else {
      res.status(404).json({ success: false, error: "Student not found" });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

  app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });